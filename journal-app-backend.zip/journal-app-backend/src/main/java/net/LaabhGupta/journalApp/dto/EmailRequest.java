package net.LaabhGupta.journalApp.dto;

public record EmailRequest(String to, String subject, String body) {
}