package net.LaabhGupta.journalApp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * This method configures Cross-Origin Resource Sharing (CORS) for the entire application.
     * It allows the frontend application (running on localhost:3000) to make requests
     * to the backend API.
     *
     * @param registry The CORS registry to which the new mapping is added.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**") // Apply CORS configuration to all endpoints under /api
                .allowedOrigins("http://localhost:3000") // Allow requests from the React frontend
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Specify allowed HTTP methods
                .allowedHeaders("*") // Allow all headers in the request
                .allowCredentials(true); // Allow cookies and authentication headers
    }
}
