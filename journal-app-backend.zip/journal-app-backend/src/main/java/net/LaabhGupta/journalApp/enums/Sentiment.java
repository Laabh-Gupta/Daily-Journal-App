package net.LaabhGupta.journalApp.enums;

public enum Sentiment {
    HAPPY,
    SAD,
    ANGRY,
    ANXIOUS
}
