package net.LaabhGupta.journalApp.service;

import org.springframework.stereotype.Service;

@Service
public class QuotesService {
    private static final String apiKey = "TxqMVuj70oca3MIArD/T7g==tXsL7BdllyRXTXG1";

}
