package net.LaabhGupta.journalApp;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled // Add this here to disable the whole class
@SpringBootTest
class JournalAppApplicationTests {

	@Test
	void contextLoads() {
		// This test will now be ignored
	}

}